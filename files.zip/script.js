/* ============================================
   PUNTA GORDA MARTIAL ARTS — Interactions
   ============================================ */

(function () {
  'use strict';

  // -----------------------------
  // Navigation: scrolled state
  // -----------------------------
  const nav = document.querySelector('.nav');
  if (nav) {
    const onScroll = () => {
      if (window.scrollY > 30) nav.classList.add('scrolled');
      else nav.classList.remove('scrolled');
    };
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
  }

  // -----------------------------
  // Mobile menu
  // -----------------------------
  const burger = document.querySelector('.burger');
  const mobileMenu = document.querySelector('.mobile-menu');
  if (burger && mobileMenu) {
    const toggle = () => {
      const open = burger.classList.toggle('open');
      mobileMenu.classList.toggle('open', open);
      document.body.style.overflow = open ? 'hidden' : '';
    };
    burger.addEventListener('click', toggle);
    mobileMenu.querySelectorAll('a').forEach((a) => {
      a.addEventListener('click', () => {
        if (a.getAttribute('href') && !a.getAttribute('href').startsWith('#submenu')) {
          burger.classList.remove('open');
          mobileMenu.classList.remove('open');
          document.body.style.overflow = '';
        }
      });
    });
  }

  // -----------------------------
  // Scroll reveal — IntersectionObserver
  // -----------------------------
  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (!reduceMotion) {
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('in');
            io.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.12, rootMargin: '0px 0px -50px 0px' }
    );
    document.querySelectorAll('.reveal, .reveal-stagger').forEach((el) => io.observe(el));
  } else {
    document.querySelectorAll('.reveal, .reveal-stagger').forEach((el) => el.classList.add('in'));
  }

  // -----------------------------
  // Stat counter animation
  // -----------------------------
  const counters = document.querySelectorAll('[data-count]');
  if (counters.length && !reduceMotion) {
    const counterIO = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (!entry.isIntersecting) return;
          const el = entry.target;
          const target = parseFloat(el.dataset.count);
          const decimals = (el.dataset.count.split('.')[1] || '').length;
          const duration = 1600;
          const start = performance.now();
          const step = (now) => {
            const t = Math.min((now - start) / duration, 1);
            const eased = 1 - Math.pow(1 - t, 3);
            const current = target * eased;
            el.textContent = decimals
              ? current.toFixed(decimals)
              : Math.round(current).toLocaleString();
            if (t < 1) requestAnimationFrame(step);
            else el.textContent = decimals ? target.toFixed(decimals) : target.toLocaleString();
          };
          requestAnimationFrame(step);
          counterIO.unobserve(el);
        });
      },
      { threshold: 0.4 }
    );
    counters.forEach((c) => counterIO.observe(c));
  } else {
    counters.forEach((c) => {
      const target = parseFloat(c.dataset.count);
      const decimals = (c.dataset.count.split('.')[1] || '').length;
      c.textContent = decimals ? target.toFixed(decimals) : target.toLocaleString();
    });
  }

  // -----------------------------
  // FAQ accordion
  // -----------------------------
  document.querySelectorAll('.faq-item').forEach((item) => {
    const q = item.querySelector('.faq-q');
    const a = item.querySelector('.faq-a');
    if (!q || !a) return;
    q.addEventListener('click', () => {
      const open = item.classList.toggle('open');
      if (open) {
        a.style.maxHeight = a.scrollHeight + 'px';
      } else {
        a.style.maxHeight = '0px';
      }
    });
  });

  // -----------------------------
  // Schedule tabs — toggle a filter class on the table
  // -----------------------------
  const scheduleTabs = document.querySelectorAll('.schedule-tab');
  const scheduleTable = document.querySelector('.schedule-table');
  if (scheduleTabs.length && scheduleTable) {
    scheduleTabs.forEach((tab) => {
      tab.addEventListener('click', () => {
        const target = tab.dataset.tab;
        scheduleTabs.forEach((t) => t.classList.toggle('active', t === tab));
        scheduleTable.classList.remove('filter-adults', 'filter-kids');
        if (target === 'adults') scheduleTable.classList.add('filter-adults');
        else if (target === 'kids') scheduleTable.classList.add('filter-kids');
        // 'all' = no filter class
      });
    });
  }

  // -----------------------------
  // Form: simple inline validation/feedback (no backend)
  // -----------------------------
  const form = document.querySelector('[data-trial-form]');
  if (form) {
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const btn = form.querySelector('button[type="submit"]');
      const original = btn.innerHTML;
      btn.innerHTML = 'Sending… <span class="arrow">→</span>';
      btn.disabled = true;
      setTimeout(() => {
        btn.innerHTML = '✓ Thanks — we\'ll be in touch';
        btn.style.background = '#16a34a';
        btn.style.color = '#fff';
        form.reset();
        setTimeout(() => {
          btn.innerHTML = original;
          btn.disabled = false;
          btn.style.background = '';
          btn.style.color = '';
        }, 3500);
      }, 800);
    });
  }

  // -----------------------------
  // Marquee — duplicate content for seamless loop
  // -----------------------------
  document.querySelectorAll('.marquee-track').forEach((track) => {
    if (track.dataset.duplicated) return;
    const clone = track.innerHTML;
    track.innerHTML = clone + clone;
    track.dataset.duplicated = 'true';
  });

  // -----------------------------
  // Smooth anchor scroll (offset for fixed nav)
  // -----------------------------
  document.querySelectorAll('a[href^="#"]').forEach((link) => {
    const href = link.getAttribute('href');
    if (href === '#' || href.length < 2) return;
    link.addEventListener('click', (e) => {
      const target = document.querySelector(href);
      if (!target) return;
      e.preventDefault();
      const top = target.getBoundingClientRect().top + window.scrollY - 80;
      window.scrollTo({ top, behavior: reduceMotion ? 'auto' : 'smooth' });
    });
  });
})();
